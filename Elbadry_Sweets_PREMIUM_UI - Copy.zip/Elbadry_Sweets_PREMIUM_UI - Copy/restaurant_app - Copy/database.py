import sqlite3

conn = sqlite3.connect("database.db")

conn.execute("""

CREATE TABLE IF NOT EXISTS users(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    username TEXT UNIQUE,
    phone TEXT,
    address TEXT,
    password TEXT

)

""")

conn.execute("""

CREATE TABLE IF NOT EXISTS orders(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    username TEXT,
    phone TEXT,
    address TEXT,
    products TEXT,
    delivery_type TEXT,
    total REAL,
    status TEXT

)

""")

conn.execute("""

CREATE TABLE IF NOT EXISTS products(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    name TEXT,
    price REAL,
    image TEXT

)

""")

conn.commit()
conn.close()

print("Database Created Successfully")