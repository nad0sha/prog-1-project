from flask import Flask, render_template, request, redirect, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = "elbadry_secret_key"

DATABASE = "database.db"

SHOP_INFO = {
    "branch_address": "فرع شبين الكوم",
    "phone": "01000000000",
    "work_time": "من 10 صباحاً إلى 12 مساءً"
}


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/")
def home():

    conn = get_db()

    products = conn.execute(
        "SELECT * FROM products ORDER BY id DESC"
    ).fetchall()

    order_notification = None

    if "user" in session:

        active_order = conn.execute(
            """
            SELECT * FROM orders
            WHERE username=?
            AND status='Pending'
            ORDER BY id DESC
            """,
            (session["user"],)
        ).fetchone()

        if active_order:
            order_notification = "لديك طلب قيد التحضير 🍰"

    conn.close()

    return render_template(
        "index.html",
        products=products,
        order_notification=order_notification,
        shop_info=SHOP_INFO
    )


@app.route("/menu")
def menu():

    conn = get_db()

    products = conn.execute(
        "SELECT * FROM products"
    ).fetchall()

    conn.close()

    return render_template(
        "menu.html",
        products=products,
        shop_info=SHOP_INFO
    )


@app.route("/add-to-cart/<int:id>")
def add_to_cart(id):

    if "cart" not in session:
        session["cart"] = []

    session["cart"].append(id)
    session.modified = True

    return redirect("/menu")


@app.route("/remove-from-cart/<int:index>")
def remove_from_cart(index):

    if "cart" in session:

        if index < len(session["cart"]):

            session["cart"].pop(index)
            session.modified = True

    return redirect("/cart")


@app.route("/cart")
def cart():

    cart_items = []
    total = 0

    if "cart" in session:

        conn = get_db()

        for product_id in session["cart"]:

            product = conn.execute(
                "SELECT * FROM products WHERE id=?",
                (product_id,)
            ).fetchone()

            if product:
                cart_items.append(product)
                total += product["price"]

        conn.close()

    return render_template(
        "cart.html",
        cart_items=cart_items,
        total=total,
        shop_info=SHOP_INFO
    )


@app.route("/register", methods=["GET", "POST"])
def register():

    error = None

    if request.method == "POST":

        username = request.form["username"]
        phone = request.form["phone"]
        address = request.form["address"]
        password = request.form["password"]

        if len(phone) != 11 or not phone.startswith("01"):
            error = "رقم الهاتف غير صحيح"
            return render_template(
        "register.html",
        error=error,
        shop_info=SHOP_INFO
    )

        conn = get_db()

        existing_user = conn.execute(
            "SELECT * FROM users WHERE username=?",
            (username,)
        ).fetchone()

        if existing_user:
            conn.close()
            error = "اسم المستخدم موجود بالفعل"
            return render_template(
        "register.html",
        error=error,
        shop_info=SHOP_INFO
    )

        conn.execute(
            "INSERT INTO users(username,phone,address,password) VALUES(?,?,?,?)",
            (username, phone, address, password)
        )

        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template(
        "register.html",
        error=error,
        shop_info=SHOP_INFO
    )


@app.route("/login", methods=["GET", "POST"])
def login():

    error = None

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_db()

        user = conn.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username, password)
        ).fetchone()

        conn.close()

        if user:
            session["user"] = username
            return redirect("/")

        error = "بيانات تسجيل الدخول غير صحيحة"

    return render_template(
        "login.html",
        error=error,
        shop_info=SHOP_INFO
    )


@app.route("/checkout", methods=["GET", "POST"])
def checkout():

    if "user" not in session:
        return redirect("/login")

    conn = get_db()

    user = conn.execute(
        "SELECT * FROM users WHERE username=?",
        (session["user"],)
    ).fetchone()

    total = 0
    products_names = []

    if "cart" in session:

        for product_id in session["cart"]:

            product = conn.execute(
                "SELECT * FROM products WHERE id=?",
                (product_id,)
            ).fetchone()

            if product:

                total += product["price"]

                products_names.append(
                    product["name"]
                )

    if request.method == "POST":

        delivery_type = request.form["delivery_type"]

        address = user["address"]

        if delivery_type == "pickup":
            address = "استلام من الفرع"

        products_text = " - ".join(products_names)

        conn.execute(
            """
            INSERT INTO orders
            (
            username,
            phone,
            address,
            products,
            delivery_type,
            total,
            status
            )

            VALUES(?,?,?,?,?,?,?)
            """,
            (
                user["username"],
                user["phone"],
                address,
                products_text,
                delivery_type,
                total,
                "Pending"
            )
        )

        conn.commit()
        conn.close()

        session["cart"] = []

        return redirect("/")

    conn.close()

    return render_template(
        "checkout.html",
        total=total,
        user=user,
        shop_info=SHOP_INFO
    )


@app.route("/done-order/<int:id>")
def done_order(id):

    if "admin" not in session:
        return redirect("/admin-login")

    conn = get_db()

    conn.execute(
        "UPDATE orders SET status='Done' WHERE id=?",
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect("/elbadry-admin-panel")


@app.route("/admin-login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "1234":

            session["admin"] = True

            return redirect("/elbadry-admin-panel")

    return render_template("admin_login.html")


@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")


@app.route("/elbadry-admin-panel")
def admin_dashboard():

    if "admin" not in session:
        return redirect("/admin-login")

    conn = get_db()

    products = conn.execute(
        "SELECT * FROM products ORDER BY id DESC"
    ).fetchall()

    orders = conn.execute(
        "SELECT * FROM orders ORDER BY id DESC"
    ).fetchall()

    conn.close()

    stats_orders = len(orders)

    total_sales = 0

    for order in orders:
        total_sales += order["total"]

    return render_template(
        "admin/dashboard.html",
        products=products,
        orders=orders,
        shop_info=SHOP_INFO,
        stats_orders=stats_orders,
        total_sales=total_sales
    )


@app.route("/update-shop-info", methods=["POST"])
def update_shop_info():

    if "admin" not in session:
        return redirect("/admin-login")

    SHOP_INFO["branch_address"] = request.form["branch_address"]
    SHOP_INFO["phone"] = request.form["phone"]
    SHOP_INFO["work_time"] = request.form["work_time"]

    return redirect("/elbadry-admin-panel")


@app.route("/add-product", methods=["POST"])
def add_product():

    if "admin" not in session:
        return redirect("/admin-login")

    name = request.form["name"]
    price = request.form["price"]

    image = request.files["image"]

    upload_folder = "static/images/products"

    os.makedirs(upload_folder, exist_ok=True)

    if image.filename != "":

        image_path = os.path.join(
            upload_folder,
            image.filename
        )

        image.save(image_path)

    else:
        image_path = "static/images/default.jpg"

    conn = get_db()

    conn.execute(
        "INSERT INTO products(name, price, image) VALUES(?,?,?)",
        (name, price, image_path)
    )

    conn.commit()
    conn.close()

    return redirect("/elbadry-admin-panel")


@app.route("/edit-product/<int:id>", methods=["POST"])
def edit_product(id):

    if "admin" not in session:
        return redirect("/admin-login")

    name = request.form["name"]
    price = request.form["price"]

    conn = get_db()

    conn.execute(
        """
        UPDATE products

        SET name=?,
        price=?

        WHERE id=?
        """,
        (name, price, id)
    )

    conn.commit()
    conn.close()

    return redirect("/elbadry-admin-panel")


@app.route("/delete-product/<int:id>")
def delete_product(id):

    if "admin" not in session:
        return redirect("/admin-login")

    conn = get_db()

    conn.execute(
        "DELETE FROM products WHERE id=?",
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect("/elbadry-admin-panel")


if __name__ == "__main__":
    app.run(debug=True)